package com.tale.dto;

/**
 * 错误提示
 * Created by biezhi on 2017/2/26.
 */
public interface ErrorCode {

    /**
     * 非法请求
     */
    String BAD_REQUEST = "BAD REQUEST";

}
