package com.tale.dto;

import com.tale.model.Metas;

/**
 * Created by biezhi on 2017/2/22.
 */
public class MetaDto extends Metas {

    private int count;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
