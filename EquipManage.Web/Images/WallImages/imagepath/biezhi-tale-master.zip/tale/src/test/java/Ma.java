import com.blade.kit.UUID;

/**
 * Created by biezhi on 2017/2/22.
 */
public class Ma {


    public static void main(String[] args) {
        System.out.println(UUID.UU64());
    }
}
