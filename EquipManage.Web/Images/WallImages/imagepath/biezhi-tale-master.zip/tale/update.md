# 更新日志


## 版本

- Tale-1.2.x：支持内嵌Sqlite，命令行一键启动，关闭，重启
- [Tale-Mysql版本](https://github.com/otale/tale/tree/tale-mysql)

## 更新日志

